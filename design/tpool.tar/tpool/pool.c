#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<errno.h>
#include<string.h>


// TODO name functions , variables aptly
typedef struct task
{
	struct task *next;
	void   (*function)(void* arg);
	void*  arg;
} task;

// Binary sem
typedef struct semaphore
{
	pthread_mutex_t mutex;
	pthread_cond_t cond;
	int var;  // 0 or 1
} semaphore;

typedef struct taskqueue
{
	pthread_mutex_t tqueue_lock;
	semaphore *more_tasks;
	task  *front;
	task  *rear;
	int   len;
} taskqueue;

typedef struct thread
{
	pthread_t pthread;
	int id;
} thread;

typedef struct tpool 
{
	int					t_count;	
	struct thread		*pool;
	taskqueue			tqueue;
	pthread_mutex_t		working_mutex;
	pthread_cond_t		working_cond;
	volatile size_t		working_cnt;  // track idle threads, change name ?
	volatile size_t		thread_cnt;   //live threads
	volatile int        stop;
} tpool;

static void tpool_wait();
static void *run(void *arg);
static int taskqueue_init(taskqueue* taskqueue_p);
static void taskqueue_destroy(taskqueue* taskqueue_p);
static void taskqueue_clear(taskqueue* taskqueue_p);
static struct task* taskqueue_pull(taskqueue* taskqueue_p);

static void semaphore_init(semaphore *semaphore_p, int value);
static void semaphore_post(semaphore *semaphore_p);
static void semaphore_wait(semaphore *semaphore_p);
static void semaphore_reset(semaphore *semaphore_p);
static void semaphore_post_all(semaphore *semaphore_p); 

static tpool tp;


int init_threadpool(int num)
{
	int i;

	memset(&tp, 0, sizeof(tpool));
	tp.pool = (thread *) malloc( num * sizeof(thread));
	if(tp.pool == NULL)
	{
		printf("failed to create tpool \n");
		// return ENOMEM
	}
	tp.t_count = num;
	tp.stop = 1;
	pthread_mutex_init(&(tp.working_mutex), NULL);
	pthread_cond_init(&tp.working_cond, NULL);

	for (i = 0; i < num; i++)
	{
		pthread_create(&tp.pool[i].pthread, NULL, run, &i);
		pthread_detach(tp.pool[i].pthread);
		tp.pool[i].id = i;
	}

	taskqueue_init(&tp.tqueue);
}

void destroy_threadpool()
{
	volatile int threads_total = tp.thread_cnt;
	double timeout = 1.0;
	time_t start, end;
	double tpassed = 0.0;


	tpool_wait();
	tp.stop = 0;
	time (&start);
	while (tpassed < timeout && tp.thread_cnt){
		semaphore_post_all(tp.tqueue.more_tasks);
		time (&end);
		tpassed = difftime(end,start);
	}

	while (tp.thread_cnt){
		semaphore_post_all(tp.tqueue.more_tasks);
		sleep(1);
	}
	taskqueue_destroy(&tp.tqueue);
	free(tp.pool);
}

static void tpool_wait()
{
	pthread_mutex_lock(&tp.working_mutex);
	while (tp.tqueue.len || tp.working_cnt) {
		pthread_cond_wait(&tp.working_cond, &tp.working_mutex);
	}
	pthread_mutex_unlock(&tp.working_mutex);
}

static void *run(void *arg)
{
	void (*func_buff)(void*);
	void*  arg_buff;

	pthread_mutex_lock(&tp.working_mutex);
	tp.thread_cnt++;
	pthread_mutex_unlock(&tp.working_mutex);

	while (tp.stop) 
	{
		sleep(1); 
		semaphore_wait(tp.tqueue.more_tasks);
		if (tp.stop) {
			pthread_mutex_lock(&tp.working_mutex);
			tp.working_cnt++;
			pthread_mutex_unlock(&tp.working_mutex);
			task* task_p = taskqueue_pull(&tp.tqueue);
			if (task_p) {
				func_buff = task_p->function;
				arg_buff  = task_p->arg;
				func_buff(arg_buff);
				free(task_p);
			}

			pthread_mutex_lock(&tp.working_mutex);
			tp.working_cnt--;
			if (!tp.working_cnt) {
				pthread_cond_signal(&tp.working_cond);
			}
			pthread_mutex_unlock(&tp.working_mutex);
		}
	}

	pthread_mutex_lock(&tp.working_mutex);
	tp.thread_cnt--;
	pthread_mutex_unlock(&tp.working_mutex);

}

static int taskqueue_init(taskqueue* taskqueue_p)
{
	taskqueue_p->len = 0;
	taskqueue_p->front = NULL;
	taskqueue_p->rear  = NULL;

	taskqueue_p->more_tasks = (semaphore *)malloc(sizeof(semaphore));
	if (taskqueue_p->more_tasks == NULL){
		return -ENOMEM;
	}
	pthread_mutex_init(&(taskqueue_p->tqueue_lock), NULL);
	semaphore_init(taskqueue_p->more_tasks, 0);

	return 0;
}

static void taskqueue_destroy(taskqueue* taskqueue_p)
{
	taskqueue_clear(taskqueue_p);
	free(taskqueue_p->more_tasks);
}

static struct task* taskqueue_pull(taskqueue* taskqueue_p)
{
	pthread_mutex_lock(&taskqueue_p->tqueue_lock);
//	printf("task  pull %d  queue len \n", taskqueue_p->len);
	task* task_p = taskqueue_p->front;

	//TODO rearrange if statments
	if(taskqueue_p->len == 0)
	{
		printf("queue empty \n");

	} else if (taskqueue_p->len == 1)
	{
		taskqueue_p->front = NULL;
		taskqueue_p->rear  = NULL;
		taskqueue_p->len = 0;
	} else {
		taskqueue_p->front = task_p->next;
		taskqueue_p->len--;
		semaphore_post(taskqueue_p->more_tasks);
	}
	pthread_mutex_unlock(&taskqueue_p->tqueue_lock);
	return task_p;
}

static void taskqueue_push(taskqueue* taskqueue_p, struct task* newtask)
{
	pthread_mutex_lock(&taskqueue_p->tqueue_lock);
	newtask->next = NULL;

	if(taskqueue_p->len == 0)
	{
		taskqueue_p->front = newtask;
		taskqueue_p->rear  = newtask;
	} else {
		taskqueue_p->rear->next = newtask;
		taskqueue_p->rear = newtask;
	}
	taskqueue_p->len++;
//	printf("push task len %d  \n", taskqueue_p->len);
	semaphore_post(taskqueue_p->more_tasks);
	pthread_mutex_unlock(&taskqueue_p->tqueue_lock);
}

int add_work(tpool *pool, void (*function_p)(void*), void* arg_p)
{
	task* newtask;

	newtask = (struct task*)malloc(sizeof(struct task));
	if (newtask == NULL)
	{
		return -ENOMEM;
	}

	newtask->function = function_p;
	newtask->arg = arg_p;

	taskqueue_push(&pool->tqueue, newtask);
	return 0;
}



static void taskqueue_clear(taskqueue* taskqueue_p)
{
	while(taskqueue_p->len){
		free(taskqueue_pull(taskqueue_p));
	}

	taskqueue_p->front = NULL;
	taskqueue_p->rear  = NULL;
	taskqueue_p->len = 0;
	semaphore_reset(taskqueue_p->more_tasks);
}

static void semaphore_init(semaphore *semaphore_p, int value) {
        if (value < 0 || value > 1) {
				printf("invalid value for binary semaphore \n");
				// ASSERT
				exit(1);
        }
        pthread_mutex_init(&(semaphore_p->mutex), NULL);
        pthread_cond_init(&(semaphore_p->cond), NULL);
        semaphore_p->var = value;
}

static void semaphore_reset(semaphore *semaphore_p) {
        semaphore_init(semaphore_p, 0);
}

static void semaphore_post(semaphore *semaphore_p) {
        pthread_mutex_lock(&semaphore_p->mutex);
        semaphore_p->var = 1;
        pthread_cond_signal(&semaphore_p->cond);
        pthread_mutex_unlock(&semaphore_p->mutex);
}

static void semaphore_post_all(semaphore *semaphore_p) {
        pthread_mutex_lock(&semaphore_p->mutex);
        semaphore_p->var = 1;
        pthread_cond_broadcast(&semaphore_p->cond);
        pthread_mutex_unlock(&semaphore_p->mutex);
}

static void semaphore_wait(semaphore *semaphore_p) {
        pthread_mutex_lock(&semaphore_p->mutex);
        while (semaphore_p->var != 1) {
                pthread_cond_wait(&semaphore_p->cond, &semaphore_p->mutex);
        }
        semaphore_p->var = 0;
        pthread_mutex_unlock(&semaphore_p->mutex);
}

void job(void *arg){
	printf("thread %u working on %d\n", (int)pthread_self(), *((int*) arg));
}

int main()
{
	int i = 0;
	int arg[] = {1,2,3,4,5};
	init_threadpool(5);

	for (i = 0; i < 5; i++){
		add_work(&tp, job, &arg[i]);
		sleep(1);
	}
	sleep(10);
	destroy_threadpool();

	return 0;
}
