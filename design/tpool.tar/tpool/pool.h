int create_threadpool(int num_threads);
void destroy_threadpool();
